package spec.concordion.results.assertEquals.success;


public class EmptyTest extends SuccessTest {
    
    public String username = "";
}
