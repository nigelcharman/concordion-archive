package org.concordion.api;


public enum Result {

    SUCCESS,
    FAILURE, 
    EXCEPTION,
    IGNORED;
}
