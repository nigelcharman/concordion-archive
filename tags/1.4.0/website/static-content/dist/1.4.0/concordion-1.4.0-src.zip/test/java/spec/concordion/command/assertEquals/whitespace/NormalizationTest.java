package spec.concordion.command.assertEquals.whitespace;



public class NormalizationTest extends WhitespaceTest {

}
