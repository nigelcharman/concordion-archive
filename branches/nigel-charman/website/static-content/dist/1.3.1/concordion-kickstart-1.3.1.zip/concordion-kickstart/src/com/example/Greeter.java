package com.example;

public class Greeter {

    public String greetingFor(String firstName) {
        return String.format("Hello %s!", firstName);
    }
}
