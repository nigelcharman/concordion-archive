package spec.concordion.results.assertEquals.failure;

import org.concordion.integration.junit3.ConcordionTestCase;

public class AnchorsTest extends ConcordionTestCase {
    // TODO

}
